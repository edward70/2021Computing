// Snake game in SFML

#include <SFML/Graphics.hpp>
#include <list>
#include <utility>
#include <cstdlib>
#include <ctime>
#include <string>

std::pair<float,float> randPoint();

int main()
{
	std::srand(std::time(nullptr)); // init PRNG
	sf::RenderWindow window(sf::VideoMode(500, 550), "Snake");
	sf::Clock clock;

	std::list<std::pair<float,float>> snake{randPoint()}; // snake represented as a list of points
	std::pair<float,float> foodPos = randPoint(); // position of food
	sf::RectangleShape food(sf::Vector2f(10.f, 10.f));
	food.setFillColor(sf::Color::Red);
	food.setPosition((float)foodPos.first, (float)foodPos.second);

	int ms = 0; // ms elapsed
	int tick = -100;
	int score = 0; // score
	enum Direction {Up, Down, Left, Right};
	Direction direction = Right; // direction

	sf::RectangleShape hud(sf::Vector2f(500.f, 50.f));
	hud.setFillColor(sf::Color::Black);
	hud.setPosition(0.f, 500.f);

	sf::Font font;
	font.loadFromFile("Roboto-Regular.ttf");
	sf::Text counter("Score: " + std::to_string(score), font, 20);
	counter.setPosition(20.f, 512.f);
	counter.setFillColor(sf::Color::White);

	bool isDead = false;
	sf::Text death("You died.", font, 30);
	death.setPosition(200,250);
	death.setFillColor(sf::Color::Red);

	sf::RectangleShape rect(sf::Vector2f(10.f, 10.f));
	rect.setFillColor(sf::Color::Black);

	while (window.isOpen())
	{
		ms = clock.getElapsedTime().asMilliseconds();

		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		if (isDead)
		{
			window.clear(sf::Color::White);
			window.draw(death);
			window.display();
			continue;
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
			direction = Left;
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
			direction = Right;
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			direction = Up;
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
			direction = Down;

		std::pair<float,float> front;
		if (ms >= tick + std::max(100-score, 20))
		{
			tick = ms;
			front = snake.front();
			switch (direction)
			{
				case Up:
					front.second = (float)(((int)front.second - 10 + 500) % 500);
					snake.push_front(front);
					break;
				case Down:
					front.second = (float)(((int)front.second + 10 + 500) % 500);
					snake.push_front(front);
					break;
				case Left:
					front.first = (float)(((int)front.first - 10 + 500) % 500);
					snake.push_front(front);
					break;
				case Right:
					front.first = (float)(((int)front.first + 10 + 500) % 500);
					snake.push_front(front);
					break;
			}

			if (front == foodPos)
			{
				foodPos = randPoint();
				food.setPosition((float)foodPos.first, (float)foodPos.second);
				++score;
				counter.setString("Score: " + std::to_string(score));
			}
		    else
		    {
				snake.pop_back();
		    }
		}

		window.clear(sf::Color::White);
		window.draw(hud);
		window.draw(counter);

		int dup = 0;
		for (std::pair<float,float> i : snake)
		{
			if (front == i)
			{
				++dup;
				if (dup == 2)
					isDead = true;
			}
			rect.setPosition(i.first, i.second);
			window.draw(rect);
		}

		window.draw(food);

		window.display();
	}

	return 0;
}

// generate random point
std::pair<float,float> randPoint()
{
	return {(float)(std::rand()%50*10), (float)(std::rand()%50*10)}; // return random point (x,y) where 0 <= x <= 500, same for y
}